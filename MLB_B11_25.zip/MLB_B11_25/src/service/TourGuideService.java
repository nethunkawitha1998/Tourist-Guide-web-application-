package service;

import java.util.ArrayList;

import model.Feedback;
import model.TourRequest;
import model.User;

public interface TourGuideService {
	public void signUp(User u);
	public User login(String un, String pw);
	public void addTourRequest(TourRequest t);
	public ArrayList<TourRequest> getAllTourRequests();
	public TourRequest getTourRequestById(String tid);
	public TourRequest updateTourRequest(String tId, TourRequest t1);
	public void removeTGR(String id);
	public void addFeedback(Feedback f1);
}

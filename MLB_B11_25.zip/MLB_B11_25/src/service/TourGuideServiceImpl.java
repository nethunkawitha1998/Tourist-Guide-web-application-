package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import model.Feedback;
import model.TourRequest;
import model.User;
import util.DBConnection;

public class TourGuideServiceImpl implements TourGuideService{
	public static final Logger log = Logger.getLogger(TourGuideServiceImpl.class.getName());
	private static Connection con;
	private static Statement sta;
	private PreparedStatement prepa;
	
	//sdfsds
	public void signUp(User u) {
		try {
			con = DBConnection.getDBConnection();
			prepa = con.prepareStatement("INSERT INTO user (username, email, password1, password2) "
					+ "VALUES (?, ?, ?, ?)");
			con.setAutoCommit(false);
			
			prepa.setString(1, u.getUsername());
			prepa.setString(2, u.getEmail());
			prepa.setString(3, u.getPassword1());
			prepa.setString(4, u.getPassword2());

			
			prepa.execute();
			con.commit();
			
		}catch(SQLException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
		
		finally {
			try {
				if(prepa != null) {
					prepa.close();
				}
				if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				log.log(Level.SEVERE, e.getMessage());
			}
		}
	}
	
	//wa
	public User login(String un, String pw) {		
		try {
			con = DBConnection.getDBConnection();
			
			prepa = con.prepareStatement("select * from user where username = ? and password1 = ?");
			prepa.setString(1, un);
			prepa.setString(2, pw);
			ResultSet rs = prepa.executeQuery();
			
			while(rs.next()) {
				User us = new User();
				us.setUsername(rs.getString(2));
				us.setPassword1(rs.getString(3));
//				us.setPassword(rs.getString(3));
//				us.setAccountType(rs.getString(4));
				
				return us;
			}
			
		}catch(Exception e) {
			System.out.println("Error in login");
		}
		return null;
	}
	
	//nethun
	public void addTourRequest(TourRequest t) {
		try {
			con = DBConnection.getDBConnection();
			prepa = con.prepareStatement("INSERT INTO tourrequest (fullname, contactnumber, visaornic, email, address, city, country, destination, message) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
			con.setAutoCommit(false);
			
			prepa.setString(1, t.getFullname());
			prepa.setString(2, t.getContactnumber());
			prepa.setString(3, t.getVisaornic());
			prepa.setString(4, t.getEmail());
			prepa.setString(5, t.getAddress());
			prepa.setString(6, t.getCity());
			prepa.setString(7, t.getCountry());
			prepa.setString(8, t.getDestination());
			prepa.setString(9, t.getMessege());
			
			prepa.execute();
			con.commit();
			
		}catch(SQLException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
	}
	
	public ArrayList<TourRequest> getAllTourRequests(){
		return actionOnTourRequest(null);
	}
	
	public TourRequest getTourRequestById(String tid) {
		return actionOnTourRequest(tid).get(0);
	}
	
	private ArrayList<TourRequest> actionOnTourRequest(String tourId){
		ArrayList<TourRequest> al = new ArrayList<TourRequest>();
		
		try {
			con = DBConnection.getDBConnection();
			
			if(tourId != null && !tourId.isEmpty()) {
				prepa = con.prepareStatement("select * from tourrequest where tourrequest.tourId = ?");
				prepa.setString(1, tourId);
				
			}
			else {
				prepa = con.prepareStatement("select * from tourrequest");
			}
			
			ResultSet rs = prepa.executeQuery();
			
			while (rs.next()) {
				TourRequest t1 = new TourRequest();
				
				t1.setTourid(rs.getInt(1));
				t1.setFullname(rs.getString(2));
				t1.setContactnumber(rs.getString(3));
				t1.setVisaornic(rs.getString(4));
				t1.setEmail(rs.getString(5));
				t1.setAddress(rs.getString(6));
				t1.setCity(rs.getString(7));
				t1.setCountry(rs.getString(8));
				t1.setDestination(rs.getString(9));
				t1.setMessege(rs.getString(10));
				
				al.add(t1);
			}
			
			
		}catch(SQLException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
		
		finally {
			try {
				if(prepa != null) {
					prepa.close();
				}
				if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				log.log(Level.SEVERE, e.getMessage());
			}
		}
		
		return al;
	}
	
public TourRequest updateTourRequest(String tId, TourRequest t1) {
		
		try {
			con = DBConnection.getDBConnection();
			prepa = con.prepareStatement("update tourrequest as p "
					+" set p.fullname = ?, p.contactnumber = ?, p.visaornic = ?, p.email = ?, p.address = ?, p.city = ?, "
					+ "p.country = ?, p.destination = ?, p.message = ?"
					+ " where p.tourId = ?");
			prepa.setString(1, t1.getFullname());
			prepa.setString(2, t1.getContactnumber());
			prepa.setString(3, t1.getVisaornic());
			prepa.setString(4, t1.getEmail());
			prepa.setString(5, t1.getAddress());
			prepa.setString(6, t1.getCity());
			prepa.setString(7, t1.getCountry());
			prepa.setString(8, t1.getDestination());
			prepa.setString(9, t1.getMessege());
			prepa.setString(10, tId);
			
			prepa.executeUpdate();
			
		}catch(SQLException e) {	
			log.log(Level.SEVERE, e.getMessage());	
		}
		
		finally {
			try {
				if(prepa != null) {
					prepa.close();
				}
				if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				log.log(Level.SEVERE, e.getMessage());
			}
		}
		
		return getTourRequestById(tId);
	}

public void removeTGR(String id) {
	if(id != null && !id.isEmpty()) {
		try {
			con = DBConnection.getDBConnection();
			prepa = con.prepareStatement("delete from tourrequest where tourrequest.tourId = ?");
			prepa.setString(1, id);
			prepa.executeUpdate();
			
		}catch(SQLException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
		finally {
			try {
				if(prepa != null) {
					prepa.close();
				}
				if(con != null) {
					con.close();
				}
			}catch(SQLException e) {
				log.log(Level.SEVERE, e.getMessage());
			}
		}
		
	}
}


//jerry
public void addFeedback(Feedback f1) {
	try {
		con = DBConnection.getDBConnection();
		prepa = con.prepareStatement("INSERT INTO feedbach (name, email, subject, message) "
				+ "VALUES (?, ?, ?, ?)");
		con.setAutoCommit(false);
		
		prepa.setString(1, f1.getName());
		prepa.setString(2, f1.getAddress());
		prepa.setString(3, f1.getSubject());
		prepa.setString(4, f1.getMessage());

		
		prepa.execute();
		con.commit();
		
	}catch(SQLException e) {
		log.log(Level.SEVERE, e.getMessage());
	}
	
	finally {
		try {
			if(prepa != null) {
				prepa.close();
			}
			if(con != null) {
				con.close();
			}
		}catch(SQLException e) {
			log.log(Level.SEVERE, e.getMessage());
		}
	}
}

	
}

package model;

public class TourRequest {
	private int tourid;
	private String fullname;
	private String contactnumber;
	private String visaornic;
	private String email;
	private String address;
	private String city;
	private String country;
	private String destination;
	private String messege;
	
	public TourRequest() {}
	
	public TourRequest(int tourid, String fullname, String contactnumber, String visaornic, String email,
			String address, String city, String country, String destination, String messege) {
		super();
		this.tourid = tourid;
		this.fullname = fullname;
		this.contactnumber = contactnumber;
		this.visaornic = visaornic;
		this.email = email;
		this.address = address;
		this.city = city;
		this.country = country;
		this.destination = destination;
		this.messege = messege;
	}

	public int getTourid() {
		return tourid;
	}

	public void setTourid(int tourid) {
		this.tourid = tourid;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getVisaornic() {
		return visaornic;
	}

	public void setVisaornic(String visaornic) {
		this.visaornic = visaornic;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getMessege() {
		return messege;
	}

	public void setMessege(String messege) {
		this.messege = messege;
	}
	
	
}

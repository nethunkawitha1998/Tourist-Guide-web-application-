package model;

public class Feedback {
	private int feedbackId;
	private String name;
	private String address;
	private String subject;
	private String message;
	
	public Feedback() {}
	
	public Feedback(int feedbackId, String name, String address, String subject, String message) {
		super();
		this.feedbackId = feedbackId;
		this.name = name;
		this.address = address;
		this.subject = subject;
		this.message = message;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
